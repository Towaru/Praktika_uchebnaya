﻿using BugTracker.Core.Enums;
using BugTracker.Core.Models;

namespace BugTracker.API.Factory
{
    public static class BugReportFactory
    {
        public static BugReport Create(
            string title,
            string description,
            string gameVersion,
            Severity severity,
            string assignedTo)
        {
            return new BugReport
            {
                Id = Guid.NewGuid(),
                Title = title,
                Description = description,
                GameVersion = gameVersion,
                Severity = severity,
                Status = Status.New,
                AssignedTo = assignedTo,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
        }
    }
}
