﻿using BugTracker.Core.Enums;
using BugTracker.Core.Interfaces;
using BugTracker.Core.Models;
using BugTracker.Core.Specifications;
using BugTracker.API.Factory;

namespace BugTracker.API.Services
{
    public class BugReportService : IBugReportService
    {
        private readonly IBugReportRepository _repository;

        public BugReportService(IBugReportRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<BugReport>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<IEnumerable<BugReport>> GetFilteredAsync(
            DateOnly? dateFrom,
            DateOnly? dateTo,
            IEnumerable<Status>? statuses,
            IEnumerable<string>? versions)
        {
            var reports = await _repository.GetAllAsync();
            var specifications = new List<ISpecification<BugReport>>();

            if (dateFrom.HasValue && dateTo.HasValue)
                specifications.Add(new DateSpecification(dateFrom.Value, dateTo.Value));

            if (statuses != null && statuses.Any())
                specifications.Add(new StatusSpecification(statuses));

            if (versions != null && versions.Any())
                specifications.Add(new VersionSpecification(versions));

            if (!specifications.Any())
                return reports;

            var andSpec = new AndSpecification<BugReport>(specifications);
            return reports.Where(r => andSpec.IsSatisfiedBy(r));
        }

        public async Task<BugReport?> GetByIdAsync(Guid id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task<BugReport> CreateAsync(
            string title,
            string description,
            string gameVersion,
            Severity severity,
            string assignedTo)
        {
            var bugReport = BugReportFactory.Create(
                title, description, gameVersion, severity, assignedTo);
            await _repository.AddAsync(bugReport);
            return bugReport;
        }

        public async Task UpdateAsync(BugReport bugReport)
        {
            await _repository.UpdateAsync(bugReport);
        }

        public async Task DeleteAsync(Guid id)
        {
            await _repository.DeleteAsync(id);
        }
    }
}
