﻿using Microsoft.AspNetCore.Mvc;
using BugTracker.Core.Enums;
using BugTracker.Core.Interfaces;
using BugTracker.Core.Models;

namespace BugTracker.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BugReportsController : ControllerBase
    {
        private readonly IBugReportService _service;

        public BugReportsController(IBugReportService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var reports = await _service.GetAllAsync();
            return Ok(reports);
        }

        [HttpGet("filter")]
        public async Task<IActionResult> GetFiltered(
            [FromQuery] DateOnly? dateFrom,
            [FromQuery] DateOnly? dateTo,
            [FromQuery] string? statuses,
            [FromQuery] string? versions)
        {
            var statusList = statuses?
                .Split(',')
                .Select(s => Enum.Parse<Status>(s.Trim()))
                .ToList();

            var versionList = versions?
                .Split(',')
                .Select(v => v.Trim())
                .ToList();

            var reports = await _service.GetFilteredAsync(
                dateFrom, dateTo, statusList, versionList);
            return Ok(reports);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var report = await _service.GetByIdAsync(id);
            if (report == null) return NotFound();
            return Ok(report);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateBugReportRequest request)
        {
            var report = await _service.CreateAsync(
                request.Title,
                request.Description,
                request.GameVersion,
                request.Severity,
                request.AssignedTo);
            return CreatedAtAction(nameof(GetById), new { id = report.Id }, report);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, [FromBody] BugReport bugReport)
        {
            if (id != bugReport.Id) return BadRequest();
            await _service.UpdateAsync(bugReport);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _service.DeleteAsync(id);
            return NoContent();
        }
    }

    public record CreateBugReportRequest(
        string Title,
        string Description,
        string GameVersion,
        Severity Severity,
        string AssignedTo);
}