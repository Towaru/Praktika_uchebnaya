﻿using System.Text.Json;
using BugTracker.Core.Interfaces;
using BugTracker.Core.Models;
using BugTracker.API.Configuration;

namespace BugTracker.API.Repositories
{
    public class JsonBugReportRepository : IBugReportRepository
    {
        private readonly string _filePath;
        private readonly JsonSerializerOptions _jsonOptions;

        public JsonBugReportRepository()
        {
            _filePath = AppSettings.Instance.DataFilePath;
            _jsonOptions = new JsonSerializerOptions
            {
                WriteIndented = true,
                Converters = { new System.Text.Json.Serialization.JsonStringEnumConverter() }
            };

            EnsureFileExists();
        }

        private void EnsureFileExists()
        {
            var directory = Path.GetDirectoryName(_filePath)!;
            if (!Directory.Exists(directory))
                Directory.CreateDirectory(directory);

            if (!File.Exists(_filePath))
                File.WriteAllText(_filePath, "[]");
        }

        private async Task<List<BugReport>> ReadAllAsync()
        {
            var json = await File.ReadAllTextAsync(_filePath);
            return JsonSerializer.Deserialize<List<BugReport>>(json, _jsonOptions) ?? new List<BugReport>();
        }

        private async Task WriteAllAsync(List<BugReport> reports)
        {
            var json = JsonSerializer.Serialize(reports, _jsonOptions);
            await File.WriteAllTextAsync(_filePath, json);
        }

        public async Task<IEnumerable<BugReport>> GetAllAsync()
        {
            return await ReadAllAsync();
        }

        public async Task<BugReport?> GetByIdAsync(Guid id)
        {
            var reports = await ReadAllAsync();
            return reports.FirstOrDefault(r => r.Id == id);
        }

        public async Task AddAsync(BugReport bugReport)
        {
            var reports = await ReadAllAsync();
            reports.Add(bugReport);
            await WriteAllAsync(reports);
        }

        public async Task UpdateAsync(BugReport bugReport)
        {
            var reports = await ReadAllAsync();
            var index = reports.FindIndex(r => r.Id == bugReport.Id);
            if (index >= 0)
            {
                bugReport.UpdatedAt = DateTime.UtcNow;
                reports[index] = bugReport;
                await WriteAllAsync(reports);
            }
        }

        public async Task DeleteAsync(Guid id)
        {
            var reports = await ReadAllAsync();
            reports.RemoveAll(r => r.Id == id);
            await WriteAllAsync(reports);
        }
    }
}
