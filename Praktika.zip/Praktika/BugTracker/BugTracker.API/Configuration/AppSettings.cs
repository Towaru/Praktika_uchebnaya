﻿namespace BugTracker.API.Configuration
{
    public class AppSettings
    {
        private static AppSettings? _instance;
        private static readonly object _lock = new object();

        public string DataFilePath { get; private set; }
        public int Port { get; private set; }

        private AppSettings()
        {
            DataFilePath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory, "data", "bugreports.json");
            Port = 5000;
        }

        public static AppSettings Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        _instance ??= new AppSettings();
                    }
                }
                return _instance;
            }
        }
    }
}
