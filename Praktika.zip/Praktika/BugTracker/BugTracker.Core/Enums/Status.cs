﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugTracker.Core.Enums
{
    public enum Status
    {
        New,
        InProgress,
        Fixed,
        Closed
    }
}
