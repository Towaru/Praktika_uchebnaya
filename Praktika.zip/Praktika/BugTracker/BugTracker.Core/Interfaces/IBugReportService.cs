﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BugTracker.Core.Models;
using BugTracker.Core.Enums;

namespace BugTracker.Core.Interfaces
{
    public interface IBugReportService
    {
        Task<IEnumerable<BugReport>> GetAllAsync();
        Task<IEnumerable<BugReport>> GetFilteredAsync(
            DateOnly? dateFrom,
            DateOnly? dateTo,
            IEnumerable<Status>? statuses,
            IEnumerable<string>? versions);
        Task<BugReport?> GetByIdAsync(Guid id);
        Task<BugReport> CreateAsync(string title, string description,
            string gameVersion, Severity severity, string assignedTo);
        Task UpdateAsync(BugReport bugReport);
        Task DeleteAsync(Guid id);
    }
}
