﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BugTracker.Core.Models;

namespace BugTracker.Core.Interfaces
{
    public interface IBugReportRepository
    {
        Task<IEnumerable<BugReport>> GetAllAsync();
        Task<BugReport?> GetByIdAsync(Guid id);
        Task AddAsync(BugReport bugReport);
        Task UpdateAsync(BugReport bugReport);
        Task DeleteAsync(Guid id);
    }
}
