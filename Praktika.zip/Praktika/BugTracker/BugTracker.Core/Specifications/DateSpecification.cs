﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BugTracker.Core.Models;

namespace BugTracker.Core.Specifications
{
    public class DateSpecification : ISpecification<BugReport>
    {
        private readonly DateOnly _from;
        private readonly DateOnly _to;

        public DateSpecification(DateOnly from, DateOnly to)
        {
            _from = from;
            _to = to;
        }

        public bool IsSatisfiedBy(BugReport entity)
        {
            var created = DateOnly.FromDateTime(entity.CreatedAt);
            return created >= _from && created <= _to;
        }
    }
}
