﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BugTracker.Core.Models;

namespace BugTracker.Core.Specifications
{
    public class VersionSpecification : ISpecification<BugReport>
    {
        private readonly IEnumerable<string> _versions;

        public VersionSpecification(IEnumerable<string> versions)
        {
            _versions = versions;
        }

        public bool IsSatisfiedBy(BugReport entity)
        {
            return _versions.Contains(entity.GameVersion);
        }
    }
}
