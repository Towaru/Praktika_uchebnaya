﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugTracker.Core.Specifications
{
    public class AndSpecification<T> : ISpecification<T>
    {
        private readonly IEnumerable<ISpecification<T>> _specifications;

        public AndSpecification(IEnumerable<ISpecification<T>> specifications)
        {
            _specifications = specifications;
        }

        public bool IsSatisfiedBy(T entity)
        {
            return _specifications.All(s => s.IsSatisfiedBy(entity));
        }
    }
}