﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BugTracker.Core.Models;
using BugTracker.Core.Enums;

namespace BugTracker.Core.Specifications
{
    public class StatusSpecification : ISpecification<BugReport>
    {
        private readonly IEnumerable<Status> _statuses;

        public StatusSpecification(IEnumerable<Status> statuses)
        {
            _statuses = statuses;
        }

        public bool IsSatisfiedBy(BugReport entity)
        {
            return _statuses.Contains(entity.Status);
        }
    }
}
