﻿using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using BugTracker.Core.Enums;

namespace BugTracker.Desktop.Converters
{
    public class SeverityToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is Severity severity)
            {
                return severity switch
                {
                    Severity.Critical => new SolidColorBrush(Color.FromRgb(239, 68, 68)),
                    Severity.High => new SolidColorBrush(Color.FromRgb(249, 115, 22)),
                    Severity.Medium => new SolidColorBrush(Color.FromRgb(234, 179, 8)),
                    Severity.Low => new SolidColorBrush(Color.FromRgb(34, 197, 94)),
                    _ => new SolidColorBrush(Colors.White)
                };
            }
            return new SolidColorBrush(Colors.White);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
