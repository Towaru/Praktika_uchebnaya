﻿using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using BugTracker.Core.Enums;

namespace BugTracker.Desktop.Converters
{
    public class StatusToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is Status status)
            {
                return status switch
                {
                    Status.New => new SolidColorBrush(Color.FromRgb(59, 130, 246)),
                    Status.InProgress => new SolidColorBrush(Color.FromRgb(234, 179, 8)),
                    Status.Fixed => new SolidColorBrush(Color.FromRgb(34, 197, 94)),
                    Status.Closed => new SolidColorBrush(Color.FromRgb(107, 114, 128)),
                    _ => new SolidColorBrush(Colors.White)
                };
            }
            return new SolidColorBrush(Colors.White);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
