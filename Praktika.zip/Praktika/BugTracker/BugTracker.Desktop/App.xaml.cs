﻿using System.Windows;

namespace BugTracker.Desktop
{
    public partial class App : Application
    {
    }
}
