﻿using System.Windows;
using BugTracker.Core.Models;
using BugTracker.Desktop.Services;
using BugTracker.Desktop.ViewModels;

namespace BugTracker.Desktop.Views
{
    public partial class EditBugReportWindow : Window
    {
        private readonly EditBugReportViewModel _viewModel;

        public EditBugReportWindow(BugReport? existingReport)
        {
            InitializeComponent();
            _viewModel = new EditBugReportViewModel(new ApiClient(), existingReport);
            DataContext = _viewModel;
        }

        private async void OnSaveClick(object sender, RoutedEventArgs e)
        {
            await _viewModel.SaveCommand.ExecuteAsync(null);
            if (_viewModel.IsSaved)
                DialogResult = true;
        }

        private void OnCancelClick(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}