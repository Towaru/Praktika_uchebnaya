﻿using System.Windows;
using BugTracker.Desktop.ViewModels;
using BugTracker.Desktop.Views;

namespace BugTracker.Desktop
{
    public partial class MainWindow : Window
    {
        private MainViewModel ViewModel => (MainViewModel)DataContext;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void OnCreateClick(object sender, RoutedEventArgs e)
        {
            var window = new EditBugReportWindow(null);
            window.Owner = this;
            if (window.ShowDialog() == true)
                _ = ViewModel.LoadBugReportsCommand.ExecuteAsync(null);
        }

        private void OnEditClick(object sender, RoutedEventArgs e)
        {
            if (ViewModel.SelectedBugReport == null)
            {
                MessageBox.Show("Выберите репорт для редактирования",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var window = new EditBugReportWindow(ViewModel.SelectedBugReport);
            window.Owner = this;
            if (window.ShowDialog() == true)
                _ = ViewModel.LoadBugReportsCommand.ExecuteAsync(null);
        }

        private void DataGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

        }
    }
}