﻿using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using BugTracker.Core.Enums;
using BugTracker.Core.Models;
using BugTracker.Desktop.Services;

namespace BugTracker.Desktop.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        private readonly ApiClient _apiClient;

        [ObservableProperty]
        private ObservableCollection<BugReport> _bugReports = new();

        [ObservableProperty]
        private BugReport? _selectedBugReport;

        [ObservableProperty]
        private DateTime? _filterDateFrom;

        [ObservableProperty]
        private DateTime? _filterDateTo;

        // Фильтры статусов
        [ObservableProperty] private bool _filterNew;
        [ObservableProperty] private bool _filterInProgress;
        [ObservableProperty] private bool _filterFixed;
        [ObservableProperty] private bool _filterClosed;

        [ObservableProperty]
        private string _filterVersion = string.Empty;

        public MainViewModel()
        {
            _apiClient = new ApiClient();
            _ = LoadBugReportsAsync();
        }

        [RelayCommand]
        private async Task LoadBugReportsAsync()
        {
            var reports = await _apiClient.GetAllAsync();
            BugReports = new ObservableCollection<BugReport>(reports);
        }

        [RelayCommand]
        private async Task ApplyFiltersAsync()
        {
            var statuses = new List<Status>();
            if (FilterNew) statuses.Add(Status.New);
            if (FilterInProgress) statuses.Add(Status.InProgress);
            if (FilterFixed) statuses.Add(Status.Fixed);
            if (FilterClosed) statuses.Add(Status.Closed);

            var versions = string.IsNullOrWhiteSpace(FilterVersion)
                ? null
                : FilterVersion.Split(',')
                    .Select(v => v.Trim())
                    .Where(v => !string.IsNullOrEmpty(v))
                    .ToList();

            var dateFrom = FilterDateFrom.HasValue
                ? DateOnly.FromDateTime(FilterDateFrom.Value) : (DateOnly?)null;
            var dateTo = FilterDateTo.HasValue
                ? DateOnly.FromDateTime(FilterDateTo.Value) : (DateOnly?)null;

            var reports = await _apiClient.GetFilteredAsync(
                dateFrom, dateTo,
                statuses.Any() ? statuses : null,
                versions);

            BugReports = new ObservableCollection<BugReport>(reports);
        }

        [RelayCommand]
        private async Task ResetFiltersAsync()
        {
            FilterDateFrom = null;
            FilterDateTo = null;
            FilterNew = false;
            FilterInProgress = false;
            FilterFixed = false;
            FilterClosed = false;
            FilterVersion = string.Empty;
            await LoadBugReportsAsync();
        }

        [RelayCommand]
        private async Task DeleteBugReportAsync()
        {
            if (SelectedBugReport == null) return;
            await _apiClient.DeleteAsync(SelectedBugReport.Id);
            await LoadBugReportsAsync();
        }
    }
}
