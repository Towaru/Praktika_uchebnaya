﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using BugTracker.Core.Enums;
using BugTracker.Core.Models;
using BugTracker.Desktop.Services;

namespace BugTracker.Desktop.ViewModels
{
    public partial class EditBugReportViewModel : ObservableObject
    {
        private readonly ApiClient _apiClient;
        private readonly BugReport? _existingReport;

        public bool IsEditMode => _existingReport != null;
        public string WindowTitle => IsEditMode ? "Редактировать репорт" : "Новый репорт";

        [ObservableProperty] private string _title = string.Empty;
        [ObservableProperty] private string _description = string.Empty;
        [ObservableProperty] private string _gameVersion = string.Empty;
        [ObservableProperty] private string _assignedTo = string.Empty;
        [ObservableProperty] private Severity _selectedSeverity = Severity.Medium;
        [ObservableProperty] private Status _selectedStatus = Status.New;

        public IEnumerable<Severity> Severities => Enum.GetValues<Severity>();
        public IEnumerable<Status> Statuses => Enum.GetValues<Status>();

        public bool IsSaved { get; private set; }

        public EditBugReportViewModel(ApiClient apiClient, BugReport? existingReport = null)
        {
            _apiClient = apiClient;
            _existingReport = existingReport;

            if (existingReport != null)
            {
                Title = existingReport.Title;
                Description = existingReport.Description;
                GameVersion = existingReport.GameVersion;
                AssignedTo = existingReport.AssignedTo;
                SelectedSeverity = existingReport.Severity;
                SelectedStatus = existingReport.Status;
            }
        }

        [RelayCommand]
        private async Task SaveAsync()
        {
            if (string.IsNullOrWhiteSpace(Title)) return;

            if (IsEditMode)
            {
                _existingReport!.Title = Title;
                _existingReport.Description = Description;
                _existingReport.GameVersion = GameVersion;
                _existingReport.AssignedTo = AssignedTo;
                _existingReport.Severity = SelectedSeverity;
                _existingReport.Status = SelectedStatus;
                await _apiClient.UpdateAsync(_existingReport);
            }
            else
            {
                await _apiClient.CreateAsync(
                    Title, Description, GameVersion, SelectedSeverity, AssignedTo);
            }

            IsSaved = true;
        }
    }
}
