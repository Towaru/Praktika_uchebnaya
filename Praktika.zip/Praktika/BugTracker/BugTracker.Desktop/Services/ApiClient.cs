﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using BugTracker.Core.Enums;
using BugTracker.Core.Models;

namespace BugTracker.Desktop.Services
{
    public class ApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly JsonSerializerOptions _jsonOptions;

        public ApiClient()
        {
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri("https://localhost:7206/")
            };
            _jsonOptions = new JsonSerializerOptions
            {
                Converters = { new JsonStringEnumConverter() },
                PropertyNameCaseInsensitive = true
            };
        }

        public async Task<List<BugReport>> GetAllAsync()
        {
            var response = await _httpClient.GetAsync("api/bugreports");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<BugReport>>(_jsonOptions)
                ?? new List<BugReport>();
        }

        public async Task<List<BugReport>> GetFilteredAsync(
            DateOnly? dateFrom,
            DateOnly? dateTo,
            List<Status>? statuses,
            List<string>? versions)
        {
            var query = new List<string>();

            if (dateFrom.HasValue)
                query.Add($"dateFrom={dateFrom.Value:yyyy-MM-dd}");
            if (dateTo.HasValue)
                query.Add($"dateTo={dateTo.Value:yyyy-MM-dd}");
            if (statuses != null && statuses.Any())
                query.Add($"statuses={string.Join(",", statuses)}");
            if (versions != null && versions.Any())
                query.Add($"versions={string.Join(",", versions)}");

            var url = "api/bugreports/filter";
            if (query.Any())
                url += "?" + string.Join("&", query);

            var response = await _httpClient.GetAsync(url);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<BugReport>>(_jsonOptions)
                ?? new List<BugReport>();
        }

        public async Task<BugReport> CreateAsync(
            string title, string description,
            string gameVersion, Severity severity, string assignedTo)
        {
            var request = new
            {
                Title = title,
                Description = description,
                GameVersion = gameVersion,
                Severity = severity.ToString(),
                AssignedTo = assignedTo
            };

            var response = await _httpClient.PostAsJsonAsync("api/bugreports", request, _jsonOptions);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<BugReport>(_jsonOptions)!;
        }

        public async Task UpdateAsync(BugReport bugReport)
        {
            var response = await _httpClient.PutAsJsonAsync(
                $"api/bugreports/{bugReport.Id}", bugReport, _jsonOptions);
            response.EnsureSuccessStatusCode();
        }

        public async Task DeleteAsync(Guid id)
        {
            var response = await _httpClient.DeleteAsync($"api/bugreports/{id}");
            response.EnsureSuccessStatusCode();
        }
    }
}
